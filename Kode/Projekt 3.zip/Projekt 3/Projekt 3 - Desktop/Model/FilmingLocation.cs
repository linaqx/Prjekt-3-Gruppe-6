﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_3___Desktop.Model
{
    class FilmingLocation
    {

        public int Id { get; set; }
        public string Name { get; set; }

        public FilmingLocation()
        {

        }
    }
}
