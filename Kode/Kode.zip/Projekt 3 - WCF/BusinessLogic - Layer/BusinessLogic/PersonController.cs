﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusinessLogic___Layer.BusinessLogic;
using Projekt_3___WCF.Model;
using WCF___library.DB;

/// <summary>
/// @Author: Group 6: Andreas L, Katrine M, Mathias L
/// @Version: 17-12-2018
/// </summary>
namespace Projekt_3___WCF.BusinessLogic
{
    public class PersonController : IPersonController 
    {
        /// <summary>
        /// constructor for Personcontroller
        /// </summary>
        public PersonController()
        {
            
        }
    }
}