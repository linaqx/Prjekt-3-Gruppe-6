﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// @Author: Group 6: Andreas L, Katrine M, Mathias L
/// @Version: 17-12-2018
/// </summary>
namespace Projekt_3___Desktop.Model
{
    public class Country
    {
        public int Id { get; set; }
        public string Name { get; set; }

        /// <summary>
        /// Constructor for Country
        /// </summary>
        public Country()
        {
                
        }
    }
}
