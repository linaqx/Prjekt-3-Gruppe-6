﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Projekt_3___WCF.Model
{
    public class Actor
    {
    }
}