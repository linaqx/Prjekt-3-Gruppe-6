﻿using Projekt_3___WCF.DB;
using Projekt_3___WCF.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// @Author: Group 6: Andreas L, Katrine M, Mathias L
/// @Version: 17-12-2018
/// </summary>
namespace WCF___library.DB
{
    public class PersonDB : IPersonDB
    {
        /// <summary>
        /// Constructor for PersonDB
        /// </summary>
        public PersonDB()
        {
            
        }
    }
}
