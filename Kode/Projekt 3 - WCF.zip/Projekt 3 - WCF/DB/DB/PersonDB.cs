﻿using Projekt_3___WCF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCF___library.DB
{
    public class PersonDB
    {


        public User FindUserById(int id)
        {
            return null;
        }

        


    }
}
