﻿using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// @Author: Group 6: Andreas L, Katrine M, Mathias L
/// @Version: 17-12-2018
/// </summary>
namespace Projekt_3___WCF.Model
{
    public class Series : Entertainment
    {

        /// <summary>
        /// Constructor for Series
        /// </summary>
        public Series()
        {

        }
    }
}